import React, { useState } from "react";

const sampleMovies = [
  {
    id: 1,
    title: "Animal (2023)",
    cast: "Ranbir Kapoor, Rashmika Mandanna",
    poster: "https://via.placeholder.com/300x450",
    rating: 8.3,
    description:
      "A gritty action-drama exploring deep family conflicts and underworld rivalries.",
    telegramLink: "https://t.me/yourchannel/animal2023",
  },
  {
    id: 2,
    title: "Pushpa 2 (2024)",
    cast: "Allu Arjun, Fahadh Faasil",
    poster: "https://via.placeholder.com/300x450",
    rating: 9.1,
    description: "The awaited return of Pushpa Raj. Fierce. Fearless. Relentless.",
    telegramLink: "https://t.me/yourchannel/pushpa2",
  },
];

export default function CineMazaX() {
  const [search, setSearch] = useState("");
  const filtered = sampleMovies.filter((m) =>
    m.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-black text-white p-4">
      <header className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-red-500">🎬 CineMazaX</h1>
        <input
          type="text"
          placeholder="🔍 Search for movies..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="bg-gray-800 text-white p-2 rounded focus:ring-2 focus:ring-red-500"
        />
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filtered.map((movie) => (
          <div
            key={movie.id}
            className="bg-gray-900 rounded-2xl shadow-lg overflow-hidden"
          >
            <div className="flex">
              <img
                src={movie.poster}
                alt={movie.title}
                className="w-1/3 object-cover"
              />
              <div className="p-4 w-2/3">
                <h2 className="text-xl font-semibold mb-1">{movie.title}</h2>
                <p className="text-sm text-gray-400">Cast: {movie.cast}</p>
                <p className="text-sm my-2">⭐ {movie.rating}/10</p>
                <p className="text-sm text-gray-300 mb-2">{movie.description}</p>
                <a
                  href={movie.telegramLink}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <button className="bg-red-600 hover:bg-red-700 w-full p-2 rounded mt-2">
                    📺 Watch / Download
                  </button>
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>

      <footer className="mt-10 text-center text-sm text-gray-600">
        © 2025 CineMazaX. All rights reserved.
      </footer>
    </div>
  );
}
